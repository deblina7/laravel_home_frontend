
//js for toggle menu
    var MenuItems = document.getElementById("MenuItems");
    MenuItems.style.maxHeight = "0px";
    function menutoggle(){
        if(MenuItems.style.maxHeight == "0px")
        {
            MenuItems.style.maxHeight = "200px"
        }
        else
        {
            MenuItems.style.maxHeight = "0px";
        }
    }


    // Add active class to the current button (highlight it)
    var header = document.getElementById("MenuItems");
    var btns = header.getElementsByClassName("activeee");
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener("click", function() {
      var current = document.getElementsByClassName("active");
      current[0].className = current[0].className.replace(" active", "");
      this.className += " active";
      });
    }


            $(document).ready(function () {
                $("#product").selectpicker();

                $("#catagories").selectpicker();

                load_data("data");

                function load_data(type, id = "") {
                    $.ajax({
                        url: "fetch.php",
                        method: "POST",
                        data: { type: type, id: id },
                        dataType: "json",
                        success: function (data) {
                            var html = "";
                            for (var count = 0; count < data.length; count++) {
                                html += '<option value="' + data[count].id + '">' + data[count].name + "</option>";
                            }
                            if (type == "data") {
                                $("#product").html(html);
                                $("#product").selectpicker("refresh");
                            } else {
                                $("#catagories").html(html);
                                $("#catagories").selectpicker("refresh");
                            }
                        },
                    });
                }

                // $(document).on("change", "#product", function () {
                //     var id = $("#product").val();
                //     load_data("carModeldata", id);
                // });
            });

