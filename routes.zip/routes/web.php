<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Frontend\homecontroller;
use App\Http\Controllers\Frontend\aboutcontroller;
use App\Http\Controllers\Frontend\accountcontroller;
use App\Http\Controllers\Frontend\Baby_Productcontroller;
use App\Http\Controllers\Frontend\Boy_Productcontroller;
use App\Http\Controllers\Frontend\cartcontroller;
use App\Http\Controllers\Frontend\contactcontroller;
use App\Http\Controllers\Frontend\forgot_passwordcontroller;
use App\Http\Controllers\Frontend\Form_designcontroller;
use App\Http\Controllers\Frontend\Girl_Productcontroller;
use App\Http\Controllers\Frontend\offercontroller;
use App\Http\Controllers\Frontend\productcontroller;
use App\Http\Controllers\Frontend\signupcontroller;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[homecontroller::class,'index']);
Route::get('/about',[aboutontroller::class,'index']);
Route::get('/account',[accountcontroller::class,'index']);
Route::get('/Baby_Product',[Baby_Productcontroller::class,'index']);
Route::get('/Boy_Rroduct',[Boy_Productcontroller::class,'index']);
Route::get('/cart',[cartcontroller::class,'index']);
Route::get('/footer',[footercontroller::class,'index']);
Route::get('/forgot_password',[forgot_passwordcontroller::class,'index']);
Route::get('/Form_deisgn',[Form_designcontroller::class,'index']);
Route::get('/Girl_Product',[Girl_Productcontroller::class,'index']);
Route::get('/offer',[offercontroller::class,'index']);
Route::get('/login',[logincontroller::class,'index']);
Route::get('/product',[productcontroller::class,'index']);
Route::get('/signup',[signupcontroller::class,'index']);
Route::get('/contact',[contactcontroller::class,'index']);
