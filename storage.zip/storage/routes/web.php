<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Frontend\homecontroller;
use App\Http\Controllers\Frontend\aboutcontroller;
use App\Http\Controllers\Frontend\accountcontroller;
use App\Http\Controllers\Frontend\Baby_Productcontroller;
use App\Http\Controllers\Frontend\Boy_Productcontroller;
use App\Http\Controllers\Frontend\cartcontroller;
use App\Http\Controllers\Frontend\contactcontroller;
use App\Http\Controllers\Frontend\forgot_passwordcontroller;
use App\Http\Controllers\Frontend\Form_designcontroller;
use App\Http\Controllers\Frontend\Girl_Productcontroller;
use App\Http\Controllers\Frontend\offercontroller;
use App\Http\Controllers\Frontend\productcontroller;
use App\Http\Controllers\Frontend\signupcontroller;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
