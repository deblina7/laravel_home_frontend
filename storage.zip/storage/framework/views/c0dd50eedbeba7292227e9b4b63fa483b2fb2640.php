<!-- ------------footer------------ -->
<div class="footer">
    <div class="container">
        <div class="row">
            <div class="footer-col-1">
                <h3 class="sizeb">Download Our App</h3>
                <p>Download App for Android ios mobile phone.</p>
                <div class="app-logo">
                    <img src="<?php echo e(asset('Front_end/images/play_store.png')); ?>" alt="image">
                    <img src="<?php echo e(asset('Front_end/images/app_store.png')); ?>" alt="image">
                </div>
            </div>
            <div class="footer-col-2">
                <img src="<?php echo e(asset('Front_end/images/logo3.png')); ?>" alt="logo">
                <p>Our Purpose Is To Make The Pleasure and Benefits of Your Baby Accessible to the Many</p>
            </div>
            <div class="footer-col-3">
                <h3 class="size">Useful Links</h3>
                <ul class="sizec">
                    <li>Coupons</li>
                    <li>Blog Post</li>
                    <li>Return Policy</li>
                    <li>Discount</li>

                </ul>
            </div>
            <div class="footer-col-4">
                <h3 class="sizea">Follow Us</h3>
                <ul>
                    <li>Facebook</li>
                    <li>Twitter</li>
                    <li>instagram</li>
                    <li>YouTube</li>
                </ul>
            </div>
        </div>
        <hr>
        <p class="copyright">© Copyright <script>document.write(new Date().getFullYear())</script> - TINY TRESSERS</p>
    </div>
</div>

<?php

// include "footer.php";

?>
<!-- <script src="suggestions.js"> -->
    <script src="<?php echo e(asset('Front_end/js/sca.js')); ?>">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js">
    <script src="<?php echo e(asset('Front_end/js/sc_lara.js')); ?>">


</body>
</html>
<?php /**PATH D:\xamppp\htdocs\laravel\convert\resources\views/frontend/divide/footer.blade.php ENDPATH**/ ?>