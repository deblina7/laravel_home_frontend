<?php #include 'session.php'; ?>

<?php $__env->startSection('main-content'); ?>
<body>

<div class="container">
    <div class="navbar">
        <div class="logo">
            <a href="<?php echo e(asset('/')); ?>"><img src="<?php echo e(asset('Front_end/images/logo2.png')); ?>" alt="logo" width="125px"></a>
        </div>

        <!-- ----------Search Box----------- -->

        <div class="Box">
            <form action="">
            <i class="fa fa-search" aria-hidden="true"></i>
            <input type="search" name="" class="search">
            <button type="submit" class="search-button">Search</button>
            </form>
        </div>

        <!-- ----------Menu Items----------- -->

        <nav>
            <ul id="MenuItems">
                <li><a href="<?php echo e(asset('/')); ?>" class="activee active">Home</a></li>
                <li><a href="<?php echo e(asset('/product')); ?>" class="activee">Products</a></li>
                <li><a href="<?php echo e(asset('/about')); ?>" class="activee">About</a></li>
                <li><a href="<?php echo e(asset('/contact')); ?>" class="activee">Contact</a></li>
                <li><a href="<?php echo e(asset('/account')); ?>" class="activee">Account</a></li>
            </ul>
        </nav>
        <a href="<?php echo e(asset('/cart')); ?>"><img src="<?php echo e(asset('Front_end/images/cart.png')); ?>" alt="cart" width="30px" height="30px"></a>
        <img src="<?php echo e(asset('Front_end/images/menu.png')); ?>" class="menu-icon"
        onclick="menutoggle()">
    </div>
</div>


<!-- ---------Boy's products----------- -->
<br><br><div class="small-container">
    <a href="Boy_Products.php"><h2 class="title">Boy's Products</h2></a>
    <div class="container-fluid">
    <div class="col-md-12">
      <div class="row">
          <?php
            $conn = mysqli_connect('localhost','root','','project');
            $Record = mysqli_query($conn,"SELECT * FROM `product`");
            while($row = mysqli_fetch_array($Record)){
              $check_page = $row['PCategory1'];
              if($check_page === 'boyindex'){
            echo "
                  <div class='clo-md-6 col-lg-4 m-auto mb-3'>
                  <form action='Insertcart.php' method='POST'>
                  <div class='card m-auto' style='width: 16rem;'>
                  <img src='../admin/admin/$row[Pimage]' class='card-img-top' alt='...'>
                  <div class='card-body text-left'>
                  <h5>$row[PName]</h5>
                  <div class='rating'>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9734;</span>
                </div>
                  <p class='rupee'>₹ $row[PPrice]</p>
                  <input type='hidden' name='PName' value='$row[PName]'>
                  <input type='hidden' name='PPrice' value='$row[PPrice]'>

                  </div>
                  </div>
                  </form>
                  </div>";
                }
              }
        ?>
      </div>
    </div>
  </div>

    <!-- ---------------girl's product------------------ -->

    <br><a href="Girl_Products.php"><h2 class="title">Girl's Products</h2></a>
    <div class="container-fluid">
    <div class="col-md-12">
      <div class="row">
          <?php
            $conn = mysqli_connect('localhost','root','','project');
            $Record = mysqli_query($conn,"SELECT * FROM `product`");
            while($row = mysqli_fetch_array($Record)){
              $check_page = $row['PCategory1'];
              if($check_page === 'girlindex'){
            echo "
                  <div class='clo-md-6 col-lg-4 m-auto mb-3'>
                  <form action='Insertcart.php' method='POST'>
                  <div class='card m-auto' style='width: 16rem;'>
                  <img src='../admin/admin/$row[Pimage]' class='card-img-top' alt='...'>
                  <div class='card-body text-left'>
                  <h5>$row[PName]</h5>
                  <div class='rating'>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9734;</span>
                </div>
                  <p class='rupee'>₹ $row[PPrice]</p>
                  <input type='hidden' name='PName' value='$row[PName]'>
                  <input type='hidden' name='PPrice' value='$row[PPrice]'>

                  </div>
                  </div>
                  </form>
                  </div>";
                }
              }
        ?>
      </div>
    </div>
  </div>


  <!-- ---------------Baby's product------------------ -->


    <br><a href="<?php echo e(asset('/Baby_Product')); ?>"><h2 class="title">Baby's Product</h2></a>
    <div class="container-fluid">
    <div class="col-md-12">
      <div class="row">
          <?php
            $conn = mysqli_connect('localhost','root','','project');
            $Record = mysqli_query($conn,"SELECT * FROM `product`");
            while($row = mysqli_fetch_array($Record)){
              $check_page = $row['PCategory1'];
              if($check_page === 'babyindex'){
            echo "
                  <div class='clo-md-6 col-lg-4 m-auto mb-3'>
                  <form action='Insertcart.php' method='POST'>
                  <div class='card m-auto' style='width: 16rem;'>
                  <img src='../admin/admin/$row[Pimage]' class='card-img-top' alt='...'>
                  <div class='card-body text-left'>
                  <h5>$row[PName]</h5>
                  <div class='rating'>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9734;</span>
                </div>
                  <p class='rupee'>₹ $row[PPrice]</p>
                  <input type='hidden' name='PName' value='$row[PName]'>
                  <input type='hidden' name='PPrice' value='$row[PPrice]'>

                  </div>
                  </div>
                  </form>
                  </div>";
                }
              }
        ?>
      </div>
    </div>
  </div>
            </div>
<?php $__env->stopSection(); ?>
<!-- ------------offer-------------- -->
<!-- ------------testimonial--------------- -->


<!-- ---------------brands--------------- -->


























<?php echo $__env->make('frontend.divide.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamppp\htdocs\laravel\convert\resources\views/frontend/product.blade.php ENDPATH**/ ?>