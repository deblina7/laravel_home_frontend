<?php echo $__env->make('frontend.divide.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('main-content'); ?>
<?php echo $__env->make('frontend.divide.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\xamppp\htdocs\laravel\convert\resources\views/frontend/divide/main.blade.php ENDPATH**/ ?>