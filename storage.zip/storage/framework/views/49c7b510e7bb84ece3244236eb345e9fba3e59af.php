<?php $__env->startSection('main-content'); ?>
<body>


<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <a href="<?php echo e(asset('/')); ?>

            "><img src="<?php echo e(asset('Front_end/images/logo2.png')); ?>" alt="logo" width="125px"> </a>
        </div>

        <!-- ----------Search Box----------- -->

        <!-- <div class="Box"> -->
            <form action="">
            <!-- <i class="fa fa-search" aria-hidden="true"></i> -->
            <div class="autocomplete">
            <input  id="myInput" type="search" name="search" onkeyup="myFunction()" >
            <!-- <input type="search" name="" class="search"> -->
            <button type="submit" class="search-button">Search</button>
            </form>
          </div>

        <!-- <div class="Box">
            <form action="">
            <i class="fa fa-search" aria-hidden="true"></i>
            <div class="autocomplete">
            <input  id="myInput" type="search" name="search" onkeyup="myFunction()" >
            <button type="submit" class="search-button" >Search</button> -->
            <!-- <div class="searchinput"> -->

                <!-- <li>Boys Graphic Print Hosiery T'Shirt </li>
                <li>Full Sleeve Solid Boys Casual Jacket </li>
                <li>New Gen-india T'Shirt(Black & White) </li>
                <li>Graphic Print Pure Cotton T'Shirt Combo </li>
                <li>MammyPoko Pants Extra-L(96 Pieces) </li>
                <li>HIMALAYA Happy Gift PackS </li> -->

             <!-- </div> -->
             <!-- </div>
            </form>
        </div> -->
        <!-- ----------Menu Items----------- -->

        <nav>
            <ul id="MenuItems">
                <!-- <i class="fa fa-search" aria-hidden="true"></i>
                <input type="search" name="" class="search"> -->
                <li><a href="<?php echo e(asset('/')); ?>" class="activee active">Home</a></li>
                <li><a href="<?php echo e(asset('/product')); ?>" class="activee">Products</a></li>
                <li><a href="<?php echo e(asset('/about')); ?>" class="activee">About</a></li>
                <li><a href="<?php echo e(asset('/contact')); ?>" class="activee">Contact</a></li>
                <li><a href="<?php echo e(asset('/account')); ?>" class="activee">Account</a></li>
            </ul>
        </nav>
        <a href="<?php echo e(asset('/cart')); ?>" class="cart"><img src="<?php echo e(asset('Front_end/images/cart.png')); ?>" alt="cart" width="30px" height="30px"></a>
        <img src="<?php echo e(asset('Front_end/images/menu.png')); ?>" class="menu-icon"
        onclick ="menutoggle()">
    </div>
    <div class="row">
        <div class="col-2">
            <h1 class="title-design">Give Your Baby<br>A New Life!</h1>
            <p>“Giving birth and being born brings us into the essence of creation, where the human spirit is courageous and bold and the body<br> miracle of wisdom.” </p>
            <a href="<?php echo e(asset('/product')); ?>" class="btn">Explore Now &#8594;</a>
        </div>
        <div class="col-2">
            <img src="<?php echo e(asset('Front_end/images/image01.png')); ?>" alt="image">
        </div>
    </div>
</div>
</div>

<!-- ---------featured categories----------- -->
<div class="categories">
    <div class="small-container">
        <div class="row">
            <div class="col-3">
                <img src="<?php echo e(asset('Front_end/images/category_1.jpg')); ?>" alt="categories">
            </div>
            <div class="col-3">
                <img src="<?php echo e(asset('Front_end/images/category_2.jpg')); ?>" alt="categories">
            </div>
            <div class="col-3">
                <img src="<?php echo e(asset('Front_end/images/category_3.jpg')); ?>" alt="categories">
            </div>
        </div>
    </div>
</div>

<!-- ---------featured products----------- -->
<div class="small-container">
    <h2 class="title">Featured Products</h2>
    <div class="container-fluid">
    <div class="col-md-12">
      <div class="row">
          <?php
            $conn = mysqli_connect('localhost','root','','project');
            $Record = mysqli_query($conn,"SELECT * FROM `product`");
            while($row = mysqli_fetch_array($Record)){
              $check_page = $row['PCategory2'];
              if($check_page === 'featuredindex'){
            echo "
                  <div class='clo-md-6 col-lg-4 m-auto mb-3'>
                  <form action='Insertcart.php' method='POST'>
                  <div class='card m-auto' style='width: 16rem;'>
                  <img src='../admin/admin/$row[Pimage]' class='card-img-top' alt='...'>
                  <div class='card-body text-left'>
                  <h5>$row[PName]</h5>
                  <div class='rating'>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9734;</span>
                </div>
                  <p class='rupee'>₹ $row[PPrice]</p>
                  <input type='hidden' name='PName' value='$row[PName]'>
                  <input type='hidden' name='PPrice' value='$row[PPrice]'>

                  </div>
                  </div>
                  </form>
                  </div>";
                }
              }
        ?>
      </div>
    </div>
  </div>


    <!-- ---------------latest product------------------ -->

    <br><h2 class="title">Latest Products</h2>
    <div class="container-fluid">
    <div class="col-md-12">
      <div class="row">
          <?php
            $conn = mysqli_connect('localhost','root','','project');
            $Record = mysqli_query($conn,"SELECT * FROM `product`");
            while($row = mysqli_fetch_array($Record)){
              $check_page = $row['PCategory2'];
              if($check_page === 'latestindex'){
            echo "
                  <div class='clo-md-6 col-lg-4 m-auto mb-3'>
                  <form action='Insertcart.php' method='POST'>
                  <div class='card m-auto' style='width: 16rem;'>
                  <img src='../admin/admin/$row[Pimage]' class='card-img-top' alt='...'>
                  <div class='card-body text-left'>
                  <h5>$row[PName]</h5>
                  <div class='rating'>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9734;</span>
                </div>
                  <p class='rupee'>₹ $row[PPrice]</p>
                  <input type='hidden' name='PName' value='$row[PName]'>
                  <input type='hidden' name='PPrice' value='$row[PPrice]'>

                  </div>
                  </div>
                  </form>
                  </div>";
                }
              }
        ?>
      </div>
    </div>
  </div>
    <br><h2 class="title">Most Visited</h2>
    <div class="container-fluid">
    <div class="col-md-12">
      <div class="row">
          <?php
            $conn = mysqli_connect('localhost','root','','project');
            $Record = mysqli_query($conn,"SELECT * FROM `product`");
            while($row = mysqli_fetch_array($Record)){
              $check_page = $row['PCategory2'];
              if($check_page === 'mostindex'){
            echo "
                  <div class='clo-md-6 col-lg-4 m-auto mb-3'>
                  <form action='Insertcart.php' method='POST'>
                  <div class='card m-auto' style='width: 16rem;'>
                  <img src='../admin/admin/$row[Pimage]' class='card-img-top' alt='...'>
                  <div class='card-body text-left'>
                  <h5>$row[PName]</h5>
                  <div class='rating'>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9734;</span>
                </div>
                  <p class='rupee'>₹ $row[PPrice]</p>
                  <input type='hidden' name='PName' value='$row[PName]'>
                  <input type='hidden' name='PPrice' value='$row[PPrice]'>

                  </div>
                  </div>
                  </form>
                  </div>";
                }
              }
        ?>
      </div>
    </div>
  </div>


<!-- ------------offer-------------- -->



<!-- ------------testimonial--------------- -->
<div class="testimonial">
    <div class="small-container">
        <div class="row">
            <div class="col-3">
                <span class="quote">&#8220;</span>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eius totam modi molestias quod quisquam error quas, quis sit enim.</p>
                <div class="rating">
                    <span>&#9733;</span>
                    <span>&#9733;</span>
                    <span>&#9733;</span>
                    <span>&#9733;</span>
                    <span>&#9734;</span>
                </div>
                <img src="<?php echo e(asset('Front_end/images/user_1.jpg')); ?>" alt="user">
                <h3>Deblina Banerjee</h3>
            </div>
            <div class="col-3">
                <span class="quote">&#8220;</span>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eius totam modi molestias quod quisquam error quas, quis sit enim.</p>
                <div class="rating">
                    <span>&#9733;</span>
                    <span>&#9733;</span>
                    <span>&#9733;</span>
                    <span>&#9733;</span>
                    <span>&#9734;</span>
                </div>
                <img src="<?php echo e(asset('Front_end/images/user_2.jpg')); ?>" alt="user">
                <h3>Priti Debnath</h3>
            </div>
            <div class="col-3">
                <span class="quote">&#8220;</span>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eius totam modi molestias quod quisquam error quas, quis sit enim.</p>
                <div class="rating">
                    <span>&#9733;</span>
                    <span>&#9733;</span>
                    <span>&#9733;</span>
                    <span>&#9733;</span>
                    <span>&#9734;</span>
                </div>
                <img src="<?php echo e(asset('Front_end/images/user_3.jpg')); ?>" alt="user">
                <h3>Anwesha Chatterjee</h3>
            </div>
        </div>
    </div>
</div>
<!-- ---------------brands--------------- -->
<div class="brands">
    <div class="small-container">
        <div class="row">
            <div class="col-5">
                <img src="<?php echo e(asset('Front_end/images/logo_godrej.png')); ?>" alt="logo">
            </div>
            <div class="col-5">
                <img src="<?php echo e(asset('Front_end/images/pampers1.jpg')); ?>" alt="logo" width="90px" height="75px">
            </div>
            <div class="col-5">
                <img src="<?php echo e(asset('Front_end/images/sp2.png')); ?>" alt="logo">
            </div>
            <div class="col-5">
                <img src="<?php echo e(asset('Front_end/images/huggies1.png')); ?>" alt="logo" width="85px" height="80px">
            </div>
            <div class="col-5">
                <img src="<?php echo e(asset('Front_end/images/logo_paypal.png')); ?>" alt="logo">
            </div>
        </div>
    </div>
</div>
 </div>

<?php $__env->stopSection(); ?>






















<?php echo $__env->make('frontend.divide.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamppp\htdocs\laravel\convert\resources\views/frontend/index.blade.php ENDPATH**/ ?>