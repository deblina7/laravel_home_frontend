<?php session_start() ?>

<?php $__env->startSection('main-content'); ?>
<body>




<div class="container">
    <div class="navbar">
        <div class="logo">
            <a href="<?php echo e(asset('/')); ?>"><img src="<?php echo e(asset('Front_end/images/logo2.png')); ?>" alt="logo" width="125px"></a>
        </div>
        <nav>
            <ul id="MenuItems">
                <li><a href="<?php echo e(asset('/')); ?>" class="activee active">Home</a></li>
                <li><a href="<?php echo e(asset('/product')); ?>" class="activee">Products</a></li>
                <li><a href="<?php echo e(asset('/about')); ?>" class="activee">About</a></li>
                <li><a href="<?php echo e(asset('/contact')); ?>" class="activee">Contact</a></li>
                <li><a href="<?php echo e(asset('/account')); ?>" class="activee">Account</a></li>
            </ul>
        </nav>
        <a href="<?php echo e(asset('/cart')); ?>"><img src="<?php echo e(asset('Front_end/images/cart.png')); ?>" alt="cart" width="30px" height="30px"></a>
        <img src="<?php echo e(asset('Front_end/images/menu.png')); ?>" class="menu-icon"
        onclick="menutoggle()">
    </div>
</div>
<!-- -------------account page-------------- -->
<div class="account-page">
    <div class="container">
        <div class="row">
            <div class="col-2">
                <img src="<?php echo e(asset('Front_end/images/image02.png')); ?>" alt="image" width="70%">
            </div>
            <div class="col-2">
                <div class="form-container">

                <?php
                if(isset($_SESSION['user'])){
                echo "<big><b>Welcome</b></big><br><br>";
                echo $_SESSION['user'];
                echo "<br><br><a href='logout.php'><input type='submit' value='Logout'><br></a> ";
                }
                else{
                    echo "<a href="{{asset('/login')}}"><input type='submit' value='Login'><br></a>
                    <p>Have an account?</p><br>
                    <a href="{{asset('/signup')}}"><input type='submit' value='Register'></a>
                    <p>Have not an account?</p>";
                }

                ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


















<?php echo $__env->make('frontend.divide.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamppp\htdocs\laravel\convert\resources\views/frontend/account.blade.php ENDPATH**/ ?>