@include('frontend.divide.header')
@yield('main-content')
@include('frontend.divide.footer')
