@extends('frontend.divide.main')
@section('main-content')
<body>




<div class="container">
    <div class="navbar">
        <div class="logo">
            <a href="{{asset('/')}}"><img src="{{asset('Front_end/images/logo2.png')}}" alt="logo" width="125px"></a>
        </div>
        <nav>
            <ul id="MenuItems">
                <li><a href="{{asset('/')}}" class="activee active">Home</a></li>
                <li><a href="{{asset('/product')}}" class="activee">Products</a></li>
                <li><a href="{{asset('/about')}}" class="activee">About</a></li>
                <li><a href="{{asset('/contact')}}" class="activee">Contact</a></li>
                <li><a href="{{asset('/account')}}" class="activee">Account</a></li>
            </ul>
        </nav>
        <a href="{{asset('/cart')}}"><img src="{{asset('Front_end/images/cart.png')}}" alt="cart" width="30px" height="30px"></a>
        <img src="{{asset('Front_end/images/menu.png')}}" class="menu-icon"
        onclick="menutoggle()">
    </div>
</div>
<!-- -------------single product------------ -->

<div class="small-container single-product">
    <div class="row">
        <div class="col-2">
            <img src="{{asset('Front_end/images/offer3.jpg')}}" alt="image" width="100%" id="ProductImg">
            <div class="small-img-row">
                <div class="small-img-col">
                    <img src="images/offer3.jpg" alt="image" width="100%" class="small-img">
                </div>
                <div class="small-img-col">
                    <img src="{{asset('Front_end/images/offer2.jpg')}}" alt="image" width="100%" class="small-img">
                </div>
                <div class="small-img-col">
                    <img src="{{asset('Front_end/images/offer1.jpg')}}" alt="image" width="100%" class="small-img">
                </div>
                <div class="small-img-col">
                    <img src="{{asset('Front_end/images/offer4.jpg')}}" alt="image" width="100%" class="small-img">
                </div>
            </div>




        </div>
        <div class="col-2">
            <p class="pp">Home / Jacket</p>
            <h2 class="hh">Winter Jacket 09</h2>
            <h3 class="rupee" style="float: inline-start;">&#x20B9;350</h3><h5 ><del class="cut-price" style="float: left;">1,249</del></h5><h4 style="color: green;float: right;" class="per-don">48% off
            </h4><br>
            <select>
                <option>Select Size</option>
                <option>1-3 Years</option>
                <option>3-5 Years</option>
                <option>5-8 Years</option>
                <option>9-12 Years</option>
                <option>13-15 Years</option>
            </select>
            <input type="number" value="1">
            <a href="Form design.html" class="btn">Buy Now</a>
            <h3>Product Details<span>&reg;</span></h3>
            <br>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Corporis, voluptates totam dolores consectetur, velit ipsam architecto, voluptatem itaque temporibus eius soluta harum reprehenderit magni at quia deleniti laborum officia blanditiis maxime sequi et quam</p>
        </div>
    </div>
</div>
<!-- -------------title------------ -->
<div class="small-container">
    <div class="row row-2">
        <h2>Related Products</h2>
        <p>View More</p>
    </div>
</div>











<!-- ------------products-------------------- -->
<div class="small-container">
    <!-- <h2 class="title">Latest Products</h2> -->

    <div class="row">
        <div class="col-4">
            <a href="product9-details.html"><img src="images/product-9.jpg" alt="product"></a>
            <a href="product9-details.html"><h4>MammyPoko Pants Extra-L(96 Pieces)</h4>
            <div class="rating">
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9734;</span>
            </div>
            <h4 class="rupee" style="float: inline-start;">&#x20B9;350</h4><h6 ><del class="cut-price" style="float: left;">1,499</del></h6><h5 style="color: green;float: right;">26% off</h5></a>
        </div>
        <div class="col-4">
            <a href="product10-details.html"><img src="images/product-10.jpg" alt="product"></a>
            <a href="product10-details.html"><h4>Cheesy Baby Sleeping Bed Combo (Pink)</h4>
            <div class="rating">
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9734;</span>
            </div>
            <h4 class="rupee" style="float: inline-start;">&#x20B9;350</h4><h6 ><del class="cut-price" style="float: left;">499</del></h6><h5 style="color: green;float: right;">26% off</h5></a>
        </div>
        <div class="col-4">
            <a href="product11-details.html"><img src="images/product-11.jpg" alt="product"></a>
            <a href="product11-details.html"><h4>Fareto Cotton Bedding Set (Blue)</h4>
            <div class="rating">
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9733;</span>
            </div>
            <h4 class="rupee" style="float: inline-start;">&#x20B9;350</h4><h6 ><del class="cut-price" style="float: left;">1,999</del></h6><h5 style="color: green;float: right;">64% off</h5></a>
        </div>
        <div class="col-4">
            <a href="product12-details.html"><img src="images/product-12.jpg" alt="product"></a>
            <a href="product12-details.html"><h4>YNA Baby Kick Play Gym Mosquito Net</h4>
            <div class="rating">
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9733;</span>
                <span>&#9734;</span>
                <span>&#9734;</span>
            </div>
            <h4 class="rupee" style="float: inline-start;">&#x20B9;350</h4><h6 ><del class="cut-price" style="float: left;">1,249</del></h6><h5 style="color: green;float: right;">48% off</h5></a>
        </div>
    </div>

</div>


<!-- ------------offer-------------- -->
<!-- ------------testimonial--------------- -->


<!-- ---------------brands--------------- -->


<!-- ------------footer------------ -->
<div class="footer">
    <div class="container">
        <div class="row">
            <div class="footer-col-1">
                <h3 class="sizeb">Download Our App</h3>
                <p>Download App for Android ios mobile phone.</p>
                <div class="app-logo">
                    <img src="images/play-store.png" alt="image">
                    <img src="images/app-store.png" alt="image">
                </div>
            </div>
            <div class="footer-col-2">
                <img src="images/logo3.png" alt="logo">
                <p>Our Purpose Is To Make The Pleasure and Benefits of Your Baby Accessible to the Many</p>
            </div>
            <div class="footer-col-3">
                <h3 class="size">Useful Links</h3>
                <ul class="sizec">
                    <li>Coupons</li>
                    <li>Blog Post</li>
                    <li>Return Policy</li>
                    <li>Discount</li>

                </ul>
            </div>
            <div class="footer-col-4">
                <h3 class="sizea">Follow Us</h3>
                <ul>
                    <li>Facebook</li>
                    <li>Twitter</li>
                    <li>instagram</li>
                    <li>YouTube</li>
                </ul>
            </div>
        </div>
        <hr>
        <p class="copyright">© Copyright <script>document.write(new Date().getFullYear())</script> - TINY TRESSERS</p>
    </div>
</div>

<!-- ----------js for toggle menu----------- -->
<script>
    var MenuItems = document.getElementById("MenuItems");
    MenuItems.style.maxHeight = "0px";
    function menutoggle(){
        if(MenuItems.style.maxHeight == "0px")
        {
            MenuItems.style.maxHeight = "200px"
        }
        else
        {
            MenuItems.style.maxHeight = "0px";
        }
    }
</script>
<!-- --------------JS for product gallery------------- -->
<script>
    var ProductImg = document.getElementById("ProductImg");
    var SmallImg = document.getElementsByClassName("small-img");

        SmallImg[0].onclick = function(){
            ProductImg.src = SmallImg[0].src;
        }
        SmallImg[1].onclick = function(){
            ProductImg.src = SmallImg[1].src;
        }
        SmallImg[2].onclick = function(){
            ProductImg.src = SmallImg[2].src;
        }
        SmallImg[3].onclick = function(){
            ProductImg.src = SmallImg[3].src;
        }


</script>

<script>
    // Add active class to the current button (highlight it)
    var header = document.getElementById("MenuItems");
    var btns = header.getElementsByClassName("activeee");
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener("click", function() {
      var current = document.getElementsByClassName("active");
      current[0].className = current[0].className.replace(" active", "");
      this.className += " active";
      });
    }
    </script>











</body>
</html>
@endsection





















