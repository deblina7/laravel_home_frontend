<?php session_start() ?>
@extends('frontend.divide.main')
@section('main-content')
<body>




<div class="container">
    <div class="navbar">
        <div class="logo">
            <a href="{{asset('/')}}"><img src="{{asset('Front_end/images/logo2.png')}}" alt="logo" width="125px"></a>
        </div>
        <nav>
            <ul id="MenuItems">
                <li><a href="{{asset('/')}}" class="activee active">Home</a></li>
                <li><a href="{{asset('/product')}}" class="activee">Products</a></li>
                <li><a href="{{asset('/about')}}" class="activee">About</a></li>
                <li><a href="{{asset('/contact')}}" class="activee">Contact</a></li>
                <li><a href="{{asset('/account')}}" class="activee">Account</a></li>
            </ul>
        </nav>
        <a href="{{asset('/cart')}}"><img src="{{asset('Front_end/images/cart.png')}}" alt="cart" width="30px" height="30px"></a>
        <img src="{{asset('Front_end/images/menu.png')}}" class="menu-icon"
        onclick="menutoggle()">
    </div>
</div>
<!-- -------------account page-------------- -->
<div class="account-page">
    <div class="container">
        <div class="row">
            <div class="col-2">
                <img src="{{asset('Front_end/images/image02.png')}}" alt="image" width="70%">
            </div>
            <div class="col-2">
                <div class="form-container">

                <?php
                if(isset($_SESSION['user'])){
                echo "<big><b>Welcome</b></big><br><br>";
                echo $_SESSION['user'];
                echo "<br><br><a href='logout.php'><input type='submit' value='Logout'><br></a> ";
                }
                else{
                    echo "<a href="{{asset('/login')}}"><input type='submit' value='Login'><br></a>
                    <p>Have an account?</p><br>
                    <a href="{{asset('/signup')}}"><input type='submit' value='Register'></a>
                    <p>Have not an account?</p>";
                }

                ?>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

















