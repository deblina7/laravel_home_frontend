@extends('frontend.divide.main')
@section('main-content')
<body>


<div class="container">
    <div class="navbar">
        <div class="logo">
            <a href="{{asset('/')}}"><img src="images/logo2.png" alt="logo" width="125px"></a>
        </div>
        <nav>
            <ul id="MenuItems">
                <li><a href="{{asset('/')}}" class="activee active">Home</a></li>
                <li><a href="{{asset('/product')}}" class="activee">Products</a></li>
                <li><a href="{{asset('/about')}}" class="activee">About</a></li>
                <li><a href="{{asset('/contact')}}" class="activee">Contact</a></li>
                <li><a href="{{asset('/account')}}" class="activee">Account</a></li>
            </ul>
        </nav>
        <a href="{{asset('cart')}}"><img src="{{asset('Front_end/images/cart.png')}}" alt="cart" width="30px" height="30px"></a>
        <img src="{{asset('Front_end/images/menu.png')}}" class="menu-icon"
        onclick="menutoggle()">
    </div>
</div>

<!-- ----------cart item details--------------- -->



    <div class="container-fluid">
        <div class="row justify-content-around my-5 mx-5">
            <div class="col-sm-12 col-md-6 col-lg-9">
                <table class="table text-center table-bordered">
                    <thead class="bg-danger text-white fs-5">
                        <th>Serial No.</th>
                        <th>Product Name</th>
                        <th>Product Price</th>
                        <th>Product Quantity</th>
                        <th>Total Price</th>
                        <th>Update</th>
                        <th>Delete</th>
                    </thead>
                    <tbody>
                       <?php
                       session_start();
                       $pTotal = 0;
                       $Total = 0;
                       $i = 0;
                       if(isset($_SESSION['cart'])){
                           foreach($_SESSION['cart'] as $key=> $value){
                               $pTotal = $value['productPrice'] * $value['productQuantity'];
                               $Total += $value['productPrice'] * $value['productQuantity'];
                               $i = $key+1;
                            echo "
                            <form action='Insertcart.php' method='POST'>
                            <tr>
                            <td>$i</td>
                            <td><input type='hidden' name='PName' value ='$value[productName]'>$value[productName]</td>
                            <td><input type='hidden' name='PPrice' value ='$value[productPrice]'>₹$value[productPrice]</td>
                            <td><input type='text' name='PQuantity' class='text-center' value ='$value[productQuantity]'></td>
                            <td>₹$pTotal</td>
                            <td><button name='update' class='btn-warning'>Update</button></td>
                            <td><button name='remove' class='btn-danger'>Delete</button></td>
                            <td><input type='hidden' name='item' value= '$value[productName]'></td>
                            </tr>
                            </form>
                            ";
                           }

                       }
                       ?>
                    </tbody>
                </table>
            </div>
            <div class="col-lg-3 text-center">
                <h3>TOTAL</h3>
                <h1 class="bg-danger text-white "><?php echo '₹'.$Total ?></h1>
            </div>
        </div>
    </div>
    <br><br><br>&nbsp&nbsp&nbsp<br><br><br>
 @endsection
