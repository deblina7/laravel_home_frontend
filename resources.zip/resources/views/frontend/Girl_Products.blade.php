@extends('frontend.divide.main')

<?php include 'session.php'; ?>

<body>
<div class="container">
    <div class="navbar">
        <div class="logo">
            <a href="index.php"><img src="images/logo2.png" alt="logo" width="125px"></a>
        </div>

        <!-- ----------Search Box----------- -->

        <div class="Box">
            <form action="">
            <i class="fa fa-search" aria-hidden="true"></i>
            <input type="search" name="" class="search">
            <button type="submit" class="search-button">Search</button>
            </form>
        </div>

        <!-- ----------Menu Items----------- -->

        <nav>
            <ul id="MenuItems">
                <li><a href="{{asset('/')}}" class="activee active">Home</a></li>
                <li><a href="{{asset('/product')}}" class="activee">Products</a></li>
                <li><a href="{{asset('/about')}}" class="activee">About</a></li>
                <li><a href="{{asset('/contact')}}" class="activee">Contact</a></li>
                <li><a href="{{asset('/account')}}" class="activee">Account</a></li>
            </ul>
        </nav>
        <a href="cart.php"><img src="images/cart.png" alt="cart" width="30px" height="30px"></a>
        <img src="images/menu.png" class="menu-icon"
        onclick="menutoggle()">
    </div>
</div>


<!-- ---------Boy's products----------- -->
<br><br><div class="small-container">
    <h2 class="title">All Products</h2>
    <div class="container-fluid">
    <div class="col-md-12">
      <div class="row">
          <?php
            $conn = mysqli_connect('localhost','root','','project');
            $Record = mysqli_query($conn,"SELECT * FROM `product`");
            while($row = mysqli_fetch_array($Record)){
              $check_page = $row['PCategory'];
              if($check_page === 'girlClothes'){
            echo "
                  <div class='clo-md-6 col-lg-4 m-auto mb-3'>
                  <form action='Insertcart.php' method='POST'>
                  <div class='card m-auto' style='width: 18rem;'>
                  <img src='../admin/admin/$row[Pimage]' class='card-img-top' alt='...'>
                  <div class='card-body text-center'>
                  <h5 class='card-title text-danger fs-4 fw-bold'>$row[PName]</h5>
                  <p class='card-text text-danger fs-4 fw-bold'>₹ $row[PPrice]</p>
                  <input type='hidden' name='PName' value='$row[PName]'>
                  <input type='hidden' name='PPrice' value='$row[PPrice]'>
                  <input type='hidden' name='PQuantity' value='1'  placeholder='Quantity'>
                  <input type='submit' name='addCart' class='btn btn-warning text-white w-100' value='Add to Cart'>
                  </div>
                  </div>
                  </form>
                  </div>";
                }
              }
        ?>
      </div>
    </div>
  </div>

</div>

