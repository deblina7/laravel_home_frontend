<?php //include 'sendmail.php' ?>

@extends('frontend.divide.main')
@section('main-content')
<body>




<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <a href="{{asset('/')}}"><img src="{{asset('Front_end/images/logo2.png')}}" alt="logo" width="125px"></a>
        </div>
        <nav>
            <ul id="MenuItems">
                <li><a href="{{asset('/')}}" class="activee active">Home</a></li>
                <li><a href="{{asset('/product')}}" class="activee">Products</a></li>
                <li><a href="{{asset('/about')}}" class="activee">About</a></li>
                <li><a href="{{asset('/contact')}}" class="activee">Contact</a></li>
                <li><a href="{{asset('/account')}}" class="activee">Account</a></li>
            </ul>
        </nav>
        <a href="{{asset('/cart')}}"><img src="{{asset('Front_end/images/cart.png')}}" alt="cart" width="30px" height="30px"></a>
        <img src="{{asset('Front_end/images/menu.png')}}" class="menu-icon"
        onclick ="menutoggle()">
    </div>
</div>

<div class="head">
    <h1>Hello...What Can We Help You!!!</h1>
</div>

 <div class="contact-section">
    <div class="contact-info">
      <div><i class="fas fa-home"></i>505 Main Road, Kolkata, West Bengal</div>
      <div><i class="fas fa-phone-alt"></i>+91 6299273302</div>
      <div><i class="fas fa-paper-plane"></i>tinytressers@gmail.com</div>
      <div><i class="fas fa-clock"></i>Mon - Fri 8:00 AM to 5:00 PM</div>
    </div>
    <!-- <h2>Feedback</h2> -->
    <div class="contact-form">
      <!-- <h2>Feedback</h2> -->
      <form class="contact" action="sendmail.php" method="get">
        <input type="text" name="name" class="text-box" placeholder="Full Name" required>
        <input type="email" name="email" class="text-box" placeholder="Email" required>
        <textarea  name="message" rows="5" placeholder="Your Feedback" required></textarea>
        <input type="submit" name="submit"  value="Send">
      </form>
    </div>
  </div>
  @endsection









