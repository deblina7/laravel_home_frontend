<?php include 'session.php'; ?>
@extends('frontend.divide.main')

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>TINY TRESSERS-- Boy's Products</title>
</head>
<body>
<div class="container">
    <div class="navbar">
        <div class="logo">
            <a href="index.php"><img src="images/logo2.png" alt="logo" width="125px"></a>
        </div>

        <!-- ----------Search Box----------- -->

        <div class="Box">
            <form action="">
            <i class="fa fa-search" aria-hidden="true"></i>
            <input type="search" name="" class="search">
            <button type="submit" class="search-button">Search</button>
            </form>
        </div>

        <!-- ----------Menu Items----------- -->

        <nav>
            <ul id="MenuItems">
                <li><a href="{{asset('/')}}" class="activee active">Home</a></li>
                <li><a href="{{asset('/product')}}" class="activee">Products</a></li>
                <li><a href="{{asset('/about')}}" class="activee">About</a></li>
                <li><a href="{{asset('/contact')}}" class="activee">Contact</a></li>
                <li><a href="{{asset('/account')}}" class="activee">Account</a></li>
            </ul>
        </nav>
        <a href="cart.php"><img src="images/cart.png" alt="cart" width="30px" height="30px"></a>
        <img src="images/menu.png" class="menu-icon"
        onclick="menutoggle()">
    </div>
</div>


<!-- ---------Boy's products----------- -->
<br><br><div class="small-container">
    <h2 class="title">All Products</h2>
    <div class="container-fluid">
    <div class="col-md-12">
      <div class="row">
          <?php
            $conn = mysqli_connect('localhost','root','','project');
            $Record = mysqli_query($conn,"SELECT * FROM `product`");
            while($row = mysqli_fetch_array($Record)){
              $check_page = $row['PCategory'];
              if($check_page === 'boyClothes'){
            echo "
                  <div class='clo-md-6 col-lg-4 m-auto mb-3'>
                  <form action='Insertcart.php' method='POST'>
                  <div class='card m-auto' style='width: 18rem;'>
                  <img src='../admin/admin/$row[Pimage]' class='card-img-top' alt='...'>
                  <div class='card-body text-center'>
                  <h5 class='card-title text-danger fs-4 fw-bold'>$row[PName]</h5>
                  <p class='card-text text-danger fs-4 fw-bold'>₹ $row[PPrice]</p>
                  <input type='hidden' name='PName' value='$row[PName]'>
                  <input type='hidden' name='PPrice' value='$row[PPrice]'>
                  <input type='hidden' name='PQuantity' value='1'  placeholder='Quantity'>
                  <input type='submit' name='addCart' class='btn btn-warning text-white w-100' value='Add to Cart'>
                  </div>
                  </div>
                  </form>
                  </div>";
                }
              }
        ?>
      </div>
    </div>
  </div>

</div>
