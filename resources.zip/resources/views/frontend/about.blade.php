@extends('frontend.divide.main')
@section('main-content')
<body>
<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <a href="index.php"><img src="{{asset('Front_end/images/logo2.png')}}" alt="logo" width="125px"></a>
        </div>
        <nav>
            <ul id="MenuItems">
                <li><a href="{{asset('/')}}" class="activee">Home</a></li>
                <li><a href="{{asset('/product')}}" class="activee">Products</a></li>
                <li><a href="{{asset('/about')}}" class="activee active">About</a></li>
                <li><a href="{{asset('/contact')}}" class="activee">Contact</a></li>
                <li><a href="{{asset('/account')}}" class="activee">Account</a></li>
            </ul>
        </nav>
        <a href="{{asset('/cart')}}"><img src="{{asset('Front_end/images/cart.png')}}" alt="cart" width="30px" height="30px"></a>
        <img src="{{asset('Front_end/images/menu.png')}}" class="menu-icon"
        onclick ="menutoggle()">
    </div>
</div>

<div class="head">
    <h1>Hello...All About Us!!!</h1>
</div>
 <div class="due">
    <p>TINY TRESSERS</p>
    <p>Version 1.1.1</p>
    <p>Build 15.02.60.103</p><br>
    <p>©2021-2022,tinytressers.com,Inc. or its affiliates</p>
 </div>
@endsection









