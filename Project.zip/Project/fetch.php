<?php
$conn = mysqli_connect("localhost","root","","project");
if (isset($_POST["type"])) {
    if ($_POST["type"] == "data") {
        $sqlQuery = "SELECT * FROM product";
        $resultset = mysqli_query($conn, $sqlQuery) or die("database error:". mysqli_error($conn));
        while( $row = mysqli_fetch_array($resultset) ) {
            $output[] = [
                'id' => $row["id"],
                'name' => $row["PName"],
            ];
        }
     echo json_encode($output); 
     } 
    //  else {
    //     $sqlQuery2 = "SELECT * FROM catagories WHERE id = '" . $_POST["category_id"] . "' ORDER BY car_models ASC";
    //     $resultset2 = mysqli_query($conn, $sqlQuery2) or die("database error:". mysqli_error($conn));
    //     while( $row2 = mysqli_fetch_array($resultset2) ) {
    //         $output[] = [
    //             'id' => $row2["model_id"],
    //             'name' => $row2["car_models"],
    //         ];
    //     }
    //     echo json_encode($output);
    // }
}
  
?>