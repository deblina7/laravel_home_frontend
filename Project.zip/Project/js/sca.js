// // getting all required elements
// querySelectorAll=0;
// searchinput=0;
// input=0;
// auto_completebox=0;
//  const searchWrapper = document.querySelector(".searchinput");
//  console.log(searchinput)
//  const inputBox = searchWrapper.querySelector("input");
//  console.log(input)
//  const suggBox = searchWrapper.querySelector(".auto_completebox");
//  console.log(auto_completebox)

 // if user press any key and release
 // inputBox.onkeyup = (e)=>{
 //     let userData = e.target.value; //user enetered data
 // }
// function myFunction() {
// var x = document.getElementByclass("search");
// x.value = x.value.toUpperCase();
// console.log(search)
// }

// function autocomplete(inp, arr) {
//   /*the autocomplete function takes two arguments,
//   the text field element and an array of possible autocompleted values:*/
//   var currentFocus;
//   /execute a function when someone writes in the text field:/
//   inp.addEventListener("input", function(e) {
//       var a, b, i, val = this.value;
//       /close any already open lists of autocompleted values/
//       closeAllLists();
//       if (!val) { return false;}
//       currentFocus = -1;
//       /create a DIV element that will contain the items (values):/
//       a = document.createElement("DIV");
//       a.setAttribute("id", this.id + "autocomplete-list");
//       a.setAttribute("class", "autocomplete-items");
//       /append the DIV element as a child of the autocomplete container:/
//       this.parentNode.appendChild(a);
//       /for each item in the array.../
//       for (i = 0; i < arr.length; i++) {
//         /check if the item starts with the same letters as the text field value:/
//         if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
//           /create a DIV element for each matching element:/
//           b = document.createElement("DIV");
//           /make the matching letters bold:/
//           b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
//           b.innerHTML += arr[i].substr(val.length);
//           /insert a input field that will hold the current array item's value:/
//           b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
//           /execute a function when someone clicks on the item value (DIV element):/
//           b.addEventListener("click", function(e) {
//               /insert the value for the autocomplete text field:/
//               inp.value = this.getElementsByTagName("input")[0].value;
//               /*close the list of autocompleted values,
//               (or any other open lists of autocompleted values:*/
//               closeAllLists();
//           });
//           a.appendChild(b);
//         }
//       }
//   });
//   /execute a function presses a key on the keyboard:/
//   inp.addEventListener("keydown", function(e) {
//       var x = document.getElementById(this.id + "autocomplete-list");
//       if (x) x = x.getElementsByTagName("div");
//       if (e.keyCode == 40) {
//         /*If the arrow DOWN key is pressed,
//         increase the currentFocus variable:*/
//         currentFocus++;
//         /and and make the current item more visible:/
//         addActive(x);
//       } else if (e.keyCode == 38) { //up
//         /*If the arrow UP key is pressed,
//         decrease the currentFocus variable:*/
//         currentFocus--;
//         /and and make the current item more visible:/
//         addActive(x);
//       } else if (e.keyCode == 13) {
//         /If the ENTER key is pressed, prevent the form from being submitted,/
//         e.preventDefault();
//         if (currentFocus > -1) {
//           /and simulate a click on the "active" item:/
//           if (x) x[currentFocus].click();
//         }
//       }
//   });
//   function addActive(x) {
//     /a function to classify an item as "active":/
//     if (!x) return false;
//     /start by removing the "active" class on all items:/
//     removeActive(x);
//     if (currentFocus >= x.length) currentFocus = 0;
//     if (currentFocus < 0) currentFocus = (x.length - 1);
//     /add class "autocomplete-active":/
//     x[currentFocus].classList.add("autocomplete-active");
//   }
//   function removeActive(x) {
//     /a function to remove the "active" class from all autocomplete items:/
//     for (var i = 0; i < x.length; i++) {
//       x[i].classList.remove("autocomplete-active");
//     }
//   }
//   function closeAllLists(elmnt) {
//     /*close all autocomplete lists in the document,
//     except the one passed as an argument:*/
//     var x = document.getElementsByClassName("autocomplete-items");
//     for (var i = 0; i < x.length; i++) {
//       if (elmnt != x[i] && elmnt != inp) {
//         x[i].parentNode.removeChild(x[i]);
//       }
//     }
//   }
//   /execute a function when someone clicks in the document:/
//   document.addEventListener("click", function (e) {
//       closeAllLists(e.target);
//   });
// }

// /An array containing all the country names in the world:/
// var suggestions = ["Channel",
// "Boys Graphic Print Hosiery T'Shirt ",
//  "Full Sleeve Solid Boys Casual Jacket ",
//  "New Gen-india T'Shirt(Black & White) ",
//  "Graphic Print Pure Cotton T'Shirt Combo ",
//  "MammyPoko Pants Extra-L(96 Pieces) ",
//  "HIMALAYA Happy Gift PackS "];

// /initiate the autocomplete function on the "myInput" element, and pass along the suggestions array as possible autocomplete values:/
// autocomplete(document.getElementByname("search"), suggestions);
// var suggestions = ["Channel",
// "Boys Graphic Print Hosiery T'Shirt ",
//  "Full Sleeve Solid Boys Casual Jacket ",
//  "New Gen-india T'Shirt(Black & White) ",
//  "Graphic Print Pure Cotton T'Shirt Combo ",
//  "MammyPoko Pants Extra-L(96 Pieces) ",
//  "HIMALAYA Happy Gift PackS"];
 
// function autocompleteMatch(input) {
//   if (input == '') {
//     return [];
//   }
//   var reg = new RegExp(input)
//   return search_terms.filter(function(term) {
// 	  if (term.match(reg)) {
//   	  return term;
// 	  }
//   });
// }
 
// function showResults(val) {
//   res = document.getElementById("result");
//   res.innerHTML = '';
//   let list = '';
//   let terms = autocompleteMatch(val);
//   for (i=0; i<terms.length; i++) {
//     list += '<li>' + terms[i] + '</li>';
//   }
//   res.innerHTML = '<ul>' + list + '</ul>';
// }

// var suggestions = [
//   "Channel",
//   "Boys Graphic Print Hosiery T'Shirt ",
//   "Full Sleeve Solid Boys Casual Jacket ",
//   "New Gen-india T'Shirt(Black & White) ",
//   "Graphic Print Pure Cotton T'Shirt Combo ",
//   "MammyPoko Pants Extra-L(96 Pieces) ",
//   "HIMALAYA Happy Gift PackS"
// ];
//    var outputAreaRef = document.getElementByclass("search-button");
//      function myfunction(){
//      var word = document.getElementByclass("search").value.toLowerCase().trim();
//    if (suggestions[word] !== undefined) {word = suggestions[word];}
//   outputAreaRef.innerHTML = word;}

function autocomplete(inp, arr) {
    /*the autocomplete function takes two arguments,
    the text field element and an array of possible autocompleted values:*/
    var currentFocus;
    /execute a function when someone writes in the text field:/
    inp.addEventListener("input", function(e) {
        var a, b, i, val = this.value;
        /close any already open lists of autocompleted values/
        closeAllLists();
        if (!val) { return false;}
        currentFocus = -1;
        /create a DIV element that will contain the items (values):/
        a = document.createElement("DIV");
        a.setAttribute("id", this.id + "autocomplete-list");
        a.setAttribute("class", "autocomplete-items");
        /append the DIV element as a child of the autocomplete container:/
        this.parentNode.appendChild(a);
        /for each item in the array.../
        for (i = 0; i < arr.length; i++) {
          /check if the item starts with the same letters as the text field value:/
          if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
            /create a DIV element for each matching element:/
            b = document.createElement("DIV");
            /make the matching letters bold:/
            b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
            b.innerHTML += arr[i].substr(val.length);
            /insert a input field that will hold the current array item's value:/
            b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
            /execute a function when someone clicks on the item value (DIV element):/
                b.addEventListener("click", function(e) {
                /insert the value for the autocomplete text field:/
                inp.value = this.getElementsByTagName("input")[0].value;
                /*close the list of autocompleted values,
                (or any other open lists of autocompleted values:*/
                closeAllLists();
            });
            a.appendChild(b);
          }
        }
    });
    /execute a function presses a key on the keyboard:/
    inp.addEventListener("keydown", function(e) {
        var x = document.getElementById(this.id + "autocomplete-list");
        if (x) x = x.getElementsByTagName("div");
        if (e.keyCode == 40) {
          /*If the arrow DOWN key is pressed,
          increase the currentFocus variable:*/
          currentFocus++;
          /and and make the current item more visible:/
          addActive(x);
        } else if (e.keyCode == 38) { //up
          /*If the arrow UP key is pressed,
          decrease the currentFocus variable:*/
          currentFocus--;
          /and and make the current item more visible:/
          addActive(x);
        } else if (e.keyCode == 13) {
          /If the ENTER key is pressed, prevent the form from being submitted,/
          e.preventDefault();
          if (currentFocus > -1) {
            /and simulate a click on the "active" item:/
            if (x) x[currentFocus].click();
          }
        }
    });
    function addActive(x) {
      /a function to classify an item as "active":/
      if (!x) return false;
      /start by removing the "active" class on all items:/
      removeActive(x);
      if (currentFocus >= x.length) currentFocus = 0;
      if (currentFocus < 0) currentFocus = (x.length - 1);
      /add class "autocomplete-active":/
      x[currentFocus].classList.add("autocomplete-active");
    }
    function removeActive(x) {
      /a function to remove the "active" class from all autocomplete items:/
      for (var i = 0; i < x.length; i++) {
        x[i].classList.remove("autocomplete-active");
      }
    }
    function closeAllLists(elmnt) {
      /*close all autocomplete lists in the document,
      except the one passed as an argument:*/
      var x = document.getElementsByClassName("autocomplete-items");
      for (var i = 0; i < x.length; i++) {
        if (elmnt != x[i] && elmnt != inp) {
        x[i].parentNode.removeChild(x[i]);
      }
    }
  }
  /execute a function when someone clicks in the document:/
  document.addEventListener("click", function (e) {
      closeAllLists(e.target);
  });
  }
  var suggestions = ["Channel",
  "Boys Graphic Print Hosiery T'Shirt ",
   "Full Sleeve Solid Boys Casual Jacket ",
   "New Gen-india T'Shirt(Black & White) ",
   "Graphic Print Pure Cotton T'Shirt Combo ",
   "MammyPoko Pants Extra-L(96 Pieces) ",
   "HIMALAYA Happy Gift PackS ","Girls Long Skirt","Girls Yellow Skirt "," Girls Top Short" , "Girls Red Skirt " ,"Rainbow Skirt " , "Girls Black Skirt"," Boys Yellow Kurta Pajama" ,"Boys Red Kurta Pajama " ," Cheesy Baby Sleeping Bed Combo", " Fareto Cotton Bedding Set" ," Winter Jacket"  ];
  
  /initiate the autocomplete function on the "myInput" element, and pass along the suggestions array as possible autocomplete values:/
  autocomplete(document.getElementById("myInput"), suggestions);